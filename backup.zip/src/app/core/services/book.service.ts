import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class BookService {

  private api = environment.apiUrl + '/api/books';

  constructor(private http: HttpClient) {}

  getAll() { return this.http.get(this.api); }
  getById(id: number) { return this.http.get(`${this.api}/${id}`); }
  search(q: string) { return this.http.get(`${this.api}/search?q=${q}`); }
  latest() { return this.http.get(`${this.api}/latest`); }
  topRated() { return this.http.get(`${this.api}/top-rated`); }
}
