import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class CartService {

  private api = environment.apiUrl + '/api/cart';

  constructor(private http: HttpClient) {}

  // ✅ FIX HERE
  getCart() {
    return this.http.get(
      this.api,
      { responseType: 'text' }   // ⬅ REQUIRED
    );
  }

  add(data: { bookId: number; quantity: number }) {
    return this.http.post(
      `${this.api}/add`,
      data,
      { responseType: 'text' }
    );
  }

  update(data: any) {
    return this.http.put(
      `${this.api}/update`,
      data,
      { responseType: 'text' }
    );
  }

  remove(bookId: number) {
    return this.http.delete(
      `${this.api}/remove/${bookId}`,
      { responseType: 'text' }
    );
  }

  clear() {
    return this.http.delete(
      `${this.api}/clear`,
      { responseType: 'text' }
    );
  }
}
