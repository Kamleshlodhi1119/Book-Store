import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class WishlistService {

  private api = environment.apiUrl + '/api/wishlist';

  constructor(private http: HttpClient) {}

  get() { return this.http.get(this.api); }
  add(bookId: number) { return this.http.post(`${this.api}/add/${bookId}`, {}); }
  remove(bookId: number) { return this.http.delete(`${this.api}/remove/${bookId}`); }
}
