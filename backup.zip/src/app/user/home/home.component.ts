import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/core/services/book.service';
import { CartService } from 'src/app/core/services/cart.service';
import { WishlistService } from 'src/app/core/services/wishlist.service';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/core/services/alert.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class UserHomeComponent implements OnInit {

  books: any[] = [];


  constructor(
    private bookService: BookService,
    private cartService: CartService,
    private wishlistService: WishlistService,
    private router: Router,private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.bookService.getAll().subscribe(res => {
      this.books = res as any[];
    });
  }

  addToCart(bookId: number) {
  this.cartService.add({ bookId, quantity: 1 }).subscribe({
    next: () =>this.alertService.show('Added to cart','success'),
    error: err => console.error(err)
  });
}


  addToWishlist(bookId: number) {
    this.wishlistService.add(bookId).subscribe();
  }

  viewBook(bookId: number) {
    this.router.navigate(['/books', bookId]); // future-ready
  }

  
}
