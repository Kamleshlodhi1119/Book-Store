import { Component, OnInit } from '@angular/core';
import { WishlistService } from 'src/app/core/services/wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  list: any[] = [];

  constructor(private wishlist: WishlistService) {}

  ngOnInit() {
    this.wishlist.get().subscribe(res => this.list = res as any[]);
  }

  remove(id: number) {
    this.wishlist.remove(id).subscribe(() => {
      this.list = this.list.filter(b => b.book.id !== id);
    });
  }
}