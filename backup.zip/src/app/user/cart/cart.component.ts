import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/core/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart: any;

  constructor(private cartService: CartService) {}

ngOnInit() {
  this.cartService.getCart().subscribe({
    next: res => {
      console.log('RAW CART RESPONSE:', res);
      this.cart = null; // avoid template crash
    },
    error: err => console.error(err)
  });
}



  load() {
    this.cartService.getCart().subscribe(c => this.cart = c);
  }

  remove(id: number) {
    this.cartService.remove(id).subscribe(() => this.load());
  }

}


  
